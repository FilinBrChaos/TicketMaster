INSERT INTO flyway_schema_history (installed_rank,"version",description,"type",script,checksum,installed_by,installed_on,execution_time,success) VALUES
	 (1,'1','schema','SQL','V1__schema.sql',-160742857,'admin','2023-04-13 13:27:45.719367',54,true);
