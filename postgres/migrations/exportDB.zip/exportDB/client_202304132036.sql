INSERT INTO client (name) VALUES
	 ('my name2');
